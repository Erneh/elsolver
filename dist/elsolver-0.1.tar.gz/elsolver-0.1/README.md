## About this code
This code is a solver I did for a college project. The idea was to be able to simulate all the possible physical scenarios, independent of dimensions, using only the lagrangian of the system ant it's associated Euler-Lagrange equations.

## Usage
To use the solver, simply install the package via pip or import via downloading the script given in the release, and call one of the solver functions (mainly elSolver)

The lagrangian of the system you wish to simulate has to be in the format given in the examples in the file

## About the future
The only piece of code uploaded now is the solver, with some silly examples, but it can tackle some more complex cases (I'll try to upload some in the future). Although in some systems, it's not able to work at all, for unspecified reasons. If any of the people who download it find something interesting about it, let me know!
